/**********************************************************************
 * Property of Lamar University
 * @author: Nitin Joshi
 * date created: Nov 13, 2013
 * Advisor: Dr. Stefan Andrei
 * --------------------------------------------------------------------
 * All rights reserved by Computer Science Department, Lamar University
 * No part of this work shall be reproduced without the consent of the 
 * Department of computer science, Lamar University or the instructor. 
 * contact: sandrei@lamar.edu
 * 			njoshi@lamar.edu
***********************************************************************/
public class TaskTriplet {
	
	int start;
	int compt;
	int deadline;
	
	public TaskTriplet() {
	
	}
	
	public TaskTriplet(int start, int compt, int deadline) {
		this.start = start;
		this.compt = compt;
		this.deadline = deadline;
	}
}
