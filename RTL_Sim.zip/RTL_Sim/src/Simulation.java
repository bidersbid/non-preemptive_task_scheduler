/**********************************************************************
 * Property of Lamar University
 * @author: Nitin Joshi
 * date created: Nov 13, 2013
 * Advisor: Dr. Stefan Andrei
 * --------------------------------------------------------------------
 * All rights reserved by Computer Science Department, Lamar University
 * No part of this work shall be reproduced without the consent of the 
 * Department of computer science, Lamar University or the instructor. 
 * contact: sandrei@lamar.edu
 * 			njoshi@lamar.edu
***********************************************************************/


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


public class Simulation {

	private int EUSI = 0;
	private int n = 0; 
	
	private ArrayList<Integer> R;
	private ArrayList<Integer> A;
	private ArrayList<Integer> s;
	private ArrayList<Integer> c;
	private ArrayList<Integer> d;
	private ArrayList<Integer> eusi;
	
	private static Scanner userFileName;
	private static PrintWriter pw;
	
	public Simulation() {
		userFileName = new Scanner(System.in);
		
		R = new ArrayList<Integer>();
		A = new ArrayList<Integer>();
		
		s = new ArrayList<Integer>();
		c = new ArrayList<Integer>();
		d = new ArrayList<Integer>();
		eusi = new ArrayList<Integer>();
	}

	void calEUSI()
	{
		eusi.clear();
		R.clear();
		A.clear();
		EUSI = 0;
		
		n = s.size();
		for(int i = 0; i<n; i++)
		{
			R.add(0);
			A.add(0);
			eusi.add(0);
		}
		
		for(int i = 0; i<n; i++) {
			R.set(i, 0);
			A.set(i, 0);
			
			for(int j = 0; j<n; j++) {
				if(j <= i)
					R.set(i, (R.get(i)+c.get(j)));
				else if((c.get(j)+d.get(i)) > d.get(j))
					R.set(i, (R.get(i)+(c.get(j)-(d.get(j)-d.get(i))))); 
		
				if(d.get(j) <= s.get(i))
					A.set(i, (A.get(i)+c.get(j)));
				else if(s.get(j) < s.get(i))
					A.set(i, (A.get(i) + min(c.get(j), (s.get(i)-s.get(j))))); 
			}
		}
		
		EUSI = 0;
		for(int i=0; i < n; i++) {
			eusi.set(i, 0);
			for(int j=0; j<n; j++) {
				if(d.get(i) > s.get(j))
					if(eusi.get(i) < (int) Math.ceil((double)(R.get(i)-A.get(j))/(double)(d.get(i)-s.get(j))))
						eusi.set(i, (int) Math.ceil((double)(R.get(i)-A.get(j))/(double)(d.get(i)-s.get(j))));
			}
			if(EUSI < eusi.get(i))
				EUSI = eusi.get(i);
		}
	}
	
	public int min(int a, int b) {
		if(a <= b)
			return a;
		else return b;
	}
/*
	public void readInput(String filename) {
		try {
			int i=0;
			
			input = new Scanner(new FileInputStream("src/"+filename+""));
			
			while(input.hasNext())
			{
				s.add(input.nextInt());
				c.add(input.nextInt());
				d.add(input.nextInt());
				System.out.println("T["+(i+1)+"] = ("+s.get(i)+", "+c.get(i)+", "+d.get(i)+")");
				i++;
			}
			
			//sort by deadline.
			
		} catch(FileNotFoundException ee) {
			System.out.println("There were some problems while trying to open/read");
			System.exit(0);
		}
	}
*/
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Simulation sim = new Simulation();
		Scanner input;
		
		System.out.println("Enter the benchmark file name : ");
		String filename = userFileName.next();
		//sim.readInput(filename);
		
		try {
			int i=0;
			int numOfTasks = 0;
			int count = 1;
			
			input = new Scanner(new FileInputStream("src/"+filename+""));
			pw = new PrintWriter (new File("src/result.txt"));
			
			pw.println("|---TaskSet---|\t-----EDF-----\t|\t-----LLF-----\t|\t-----C-----\t|\t-----D-----\t|");
			pw.flush();
			pw.println("====================================================================================");
			pw.flush();
			
			numOfTasks = input.nextInt();
			
			while(input.hasNext())
			{
				sim.s.add(input.nextInt());
				sim.c.add(input.nextInt());
				sim.d.add(input.nextInt());
				//System.out.println("T["+(i+1)+"] = ("+sim.s.get(i)+", "+sim.c.get(i)+", "+sim.d.get(i)+")");
				
				if(i == numOfTasks-1) {
					
					sim.calEUSI();
					System.out.println("EUSI = "+sim.EUSI);
					
					pw.print("\tTask Set "+count+"\t");
					
					EDF edf = new EDF();
					edf.algoEDF(sim.EUSI, sim.n, sim.s, sim.c, sim.d, pw);
					pw.flush();
					
					LLF llf = new LLF();
					llf.algoLLF(sim.EUSI, sim.n, sim.s, sim.c, sim.d, pw);
					pw.flush();
					
					AlgorithmC c = new AlgorithmC();
					c.algoC(sim.EUSI, sim.n, sim.s, sim.c, sim.d, pw);
					pw.flush();
					
					D d = new D();
					d.algoD(sim.EUSI, sim.n, sim.s, sim.c, sim.d, pw);
					pw.flush();
					
					sim.s.clear();
					sim.c.clear();
					sim.d.clear();
					i = -1;
					numOfTasks = 0;
					
					count++;
					pw.println();
					pw.flush();
					
					if(input.hasNext()) 
						numOfTasks = input.nextInt();
				}
				i++;
			}
			
			//sort by deadline.
			
		} catch(FileNotFoundException ee) {
			System.out.println("There were some problems while trying to open/read");
			System.exit(0);
		}
		//sim.display();
		pw.close();
	}

}
