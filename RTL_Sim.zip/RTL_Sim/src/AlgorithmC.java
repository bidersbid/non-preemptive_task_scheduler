/**********************************************************************
 * Property of Lamar University
 * @author: Nitin Joshi
 * date created: Nov 13, 2013
 * Advisor: Dr. Stefan Andrei
 * --------------------------------------------------------------------
 * All rights reserved by Computer Science Department, Lamar University
 * No part of this work shall be reproduced without the consent of the 
 * Department of computer science, Lamar University or the instructor. 
 * contact: sandrei@lamar.edu
 * 			njoshi@lamar.edu
***********************************************************************/

import java.io.PrintWriter;
import java.util.ArrayList;


public class AlgorithmC {

	private boolean feasible = true;
	private int noOfChains = 0;
	private int indexChosed;
	
	private ArrayList<TaskTriplet> T;
	private ArrayList<TaskTriplet> chain;
	
	public AlgorithmC() {
		T = new ArrayList<TaskTriplet>();
	}

	public void lexiSortTasks(int n, ArrayList<Integer> s, ArrayList<Integer> c, ArrayList<Integer> d) {
		int temp[] = new int[n];
		TaskTriplet task;
		
		for(int i = 0; i < n; i++) {
			temp[i] = d.get(i) - c.get(i);
			task = new TaskTriplet();
			task.start = s.get(i);
			task.compt = c.get(i);
			task.deadline = d.get(i);
			T.add(task);
		}
		
		int a;
		TaskTriplet b;
		for(int i=0; i<n; i++) {
			for(int j=0; j<n-i-1; j++) {
				if(temp[j] > temp[j+1]) {
					a = temp[j];
					b = T.get(j);
					
					temp[j] = temp[j+1];
					T.set(j, T.get(j+1));
					
					temp[j+1] = a;
					T.set(j+1, b);
				}
			}
		}
		//for(int i=0; i<n; i++)
			//System.out.println("("+T.get(i).start+", "+T.get(i).compt+", "+T.get(i).deadline+")");
	}
	
	public void algoC(int EUSI, int n, ArrayList<Integer> s, ArrayList<Integer> c, ArrayList<Integer> d, PrintWriter pw) {

		long startTime = System.nanoTime();
		
		lexiSortTasks(n, s, c, d);
		noOfChains = EUSI;
		int S;
		ArrayList<ArrayList<TaskTriplet>> C = new ArrayList<ArrayList<TaskTriplet>>();
		
		for(int i=0; i<noOfChains; i++) {
			chain = new ArrayList<TaskTriplet>();
			//chain.add(null);
			C.add(chain);
		}
		
		while (!T.isEmpty() && feasible) {
			S = minStartTime(s, n);
			for(int i=0; i<noOfChains; i++) {
				if (S > costOfChain(C.get(i))) {
					//add idle task to chain C until time S
					//I represented this idle task by the triplet<0,S,0>
					C.get(i).add(new TaskTriplet(0, S, 0));
					//merge the two task, if last two are idle.
				}
			}
			
			TaskTriplet firstTask = getFirstTask(T, C);
			if(firstTask == null) {
				System.out.println("Fatal: This is unexpected....Stopping now!");
				System.exit(0);
			}
			
			int selectedChain = selectChainToAppend(firstTask, C);
			if(selectedChain >= 0)
			{
				//remove firstTask from T and add to selected chain.
				C.get(selectedChain).add(firstTask);
				T.remove(indexChosed);
				T.trimToSize();
			}
			else {
				selectedChain = selectChainByTOR(firstTask, C);
				if (selectedChain >= 0) {
					C.get(selectedChain).add(firstTask);
					swapLast(C, selectedChain);
					T.remove(indexChosed);
					T.trimToSize();
				}
				else {
					System.out.println("This Task set is not feasible on "+EUSI+"-processor platform");
					feasible = false;
				}
			}
		}
		
		if(feasible) {
			System.out.println("This Task set is Feasible on "+EUSI+"-processor platform");
			pw.print("\tYES\t");
		}
		else {
			System.out.println("Not Feasible.");
			pw.print("\tNO\t");
		}
		
		long endTime = System.nanoTime();
		pw.print(" "+(endTime-startTime)+"\t");
	}
	
	public void swapLast(ArrayList<ArrayList<TaskTriplet>> C, int selectedChain) {
		if(C.get(selectedChain).size() > 1) {
			TaskTriplet temp = C.get(selectedChain).get(C.get(selectedChain).size()-1);
			C.get(selectedChain).set(C.get(selectedChain).size()-1, C.get(selectedChain).get(C.get(selectedChain).size()-2));
			C.get(selectedChain).set(C.get(selectedChain).size()-1, temp);
		}
	}
	
	public int selectChainByTOR(TaskTriplet firstTask, ArrayList<ArrayList<TaskTriplet>> C) {
		int x;
		for(int i=0; i<noOfChains; i++) {
			TaskTriplet last = C.get(i).get(C.get(i).size()-1);
			x = costOfChain(C.get(i)) - last.compt;
			
		/*	if(firstTask.deadline < x+last.compt+firstTask.compt && 
					x+last.compt+firstTask.compt <= last.deadline &&
					last.start <= x && firstTask.start <= x)
		*/
			if(x == (last.deadline - last.compt - firstTask.compt) && 
					last.start <= x && firstTask.start <= x )
				return i;
		}
		return -1;
	}
	
	//this method returns the chain number if it exists else it returns -1.
	public int selectChainToAppend(TaskTriplet firstTask, ArrayList<ArrayList<TaskTriplet>> C) {
		for(int i=0; i<noOfChains; i++) {
			
			if(costOfChain(C.get(i)) < firstTask.start )
				C.get(i).add(new TaskTriplet(0,(firstTask.start - costOfChain(C.get(i))),0));
			
			if(firstTask.compt + costOfChain(C.get(i)) <= firstTask.deadline)
				return i;
		}
		return -1;
	}
	
//***********************old version*********************************	
	/*public TaskTriplet getFirstTask(ArrayList<TaskTriplet> T, ArrayList<ArrayList<TaskTriplet>> C) {
		for(int i=0; i<noOfChains; i++) {
			for(int j=0;j<T.size(); j++) {
				if (T.get(j).start <= costOfChain(C.get(i))) { 
					indexChosed = j;
					return T.get(j);
				}
				else {
					System.out.println("!Warning: Cannot Find a Task such that s(T) <= c(C)");
					//System.exit(0);
					//feasible = false;
				}
			}
		}
		return null;
	}*/
	
	//*************************new Version******************************
	public TaskTriplet getFirstTask(ArrayList<TaskTriplet> T, ArrayList<ArrayList<TaskTriplet>> C) {
		for(int i=0; i<noOfChains; i++) {
			for(int j=0;j<T.size(); j++) {
				if(T.get(j).start > costOfChain(C.get(i)))
					C.get(i).add(new TaskTriplet(0,T.get(j).start,0));
				if (T.get(j).start <= costOfChain(C.get(i))) { 
					indexChosed = j;
					return T.get(j);
				}
				else {
					System.out.println("!Warning: Cannot Find a Task such that s(T) <= c(C)");
					//System.exit(0);
					//feasible = false;
				}
			}
		}
		return null;
	}
	
	public int costOfChain(ArrayList<TaskTriplet> chain) {
		int cost = 0;
		if (chain.size() == 0)
			return 0;
		else {
			for(int i=0; i<chain.size(); i++)
				cost+=chain.get(i).compt;
		}
		return cost;
	}
	
	public int minStartTime(ArrayList<Integer> s, int n) { 
		int temp;
		Integer arr[] = new Integer[n];
		for(int i = 0; i<n; i++)
			arr[i] = s.get(i);
		for(int i=0; i<n; i++) {
			for(int j=0; j<n-i-1; j++) {
				if (arr[j] > arr[j+1]) {
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		return arr[0];
	}
	
	public void display() {
		//System.out.println(" EUSI is : "+ EUSI);
	}
/*	
	public void readInput(String filename) {
		try {
			int i=0;
			
			input = new Scanner(new FileInputStream("src/"+filename+""));
			
			while(input.hasNext())
			{
				s.add(input.nextInt());
				c.add(input.nextInt());
				d.add(input.nextInt());
				System.out.println("T["+(i+1)+"] = ("+s.get(i)+", "+c.get(i)+", "+d.get(i)+")");
				i++;
			}
			
			//sort by deadline.
			
		} catch(FileNotFoundException ee) {
			System.out.println("There were some problems while trying to open/read");
			System.exit(0);
		}
	}

	public static void main(String[] args) {
		AlgorithmC simC = new AlgorithmC();
		System.out.println("Enter the benchmark file name : ");
		String filename = userFileName.next();
		simC.readInput(filename);
		simC.algoC();
		//sim.display();
	}
*/
}

